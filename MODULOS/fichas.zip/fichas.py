# -*- coding: utf-8 -*-
"""Módulo de consola - Fichas Técnicas Host AI Sprint 5.9"""
from __future__ import annotations
import copy
from fichas_tecnicas import buscar_fichas_por_texto,cargar_ficha,completar_ficha_con_preguntas,crear_ficha_carrillera_demo,crear_ficha_desde_receta_basica,dict_a_ficha,elegir_ficha_por_nombre_o_codigo,estado_ficha,guardar_dict_ficha,guardar_ficha,listar_fichas,preguntas_para_completar,resumen_para_cocinero
from interprete_fichas import aplicar_cambio_a_dict, interpretar_cambio
from versionado_fichas import guardar_version, leer_historial, registrar_cambio

def _pausa(): input('')
Pulsa ENTER para continuar...')
def _pedir_ficha_por_nombre():
    texto=input('
Nombre del plato/elaboración o código interno: ').strip(); ficha=elegir_ficha_por_nombre_o_codigo(texto)
    if not ficha: print('
No he encontrado ninguna ficha con ese nombre o código.'); return None
    return ficha

def _crear_demo_carrillera():
    path=guardar_ficha(crear_ficha_carrillera_demo()); print('
Ficha demo creada correctamente.'); print(f'Archivo: {path}')
def _listar_fichas():
    fichas=listar_fichas()
    if not fichas: print('
No hay fichas guardadas todavía.'); return
    print('
FICHAS TÉCNICAS GUARDADAS'); print('='*70)
    for f in fichas:
        try:
            data=cargar_ficha(f.stem); print(f"- {data.get('nombre',f.stem)} | Código interno: {f.stem} | {estado_ficha(data or {})}")
        except Exception: print(f'- {f.stem}')
def _ver_ficha():
    ficha=_pedir_ficha_por_nombre()
    if ficha: print(resumen_para_cocinero(ficha))
def _crear_borrador_desde_texto():
    print('
Pega una receta básica. Cuando termines, escribe una línea solo con FIN.')
    lineas=[]
    while True:
        linea=input()
        if linea.strip().upper()=='FIN': break
        lineas.append(linea)
    ficha=crear_ficha_desde_receta_basica('
'.join(lineas))
    print('
BORRADOR GENERADO'); print('='*70); print(f'Nombre detectado: {ficha.nombre}'); print(f'Código interno propuesto: {ficha.codigo}'); print(f'Ingredientes detectados: {len(ficha.ingredientes)}'); print(f'Fases detectadas: {len(ficha.fases)}')
    preguntas=preguntas_para_completar(ficha)
    if preguntas:
        print('
Host AI necesita completar estos campos:')
        for i,(_,pregunta) in enumerate(preguntas,1): print(f'{i}. {pregunta}')
    if input('
¿Quieres responder ahora las preguntas y completar la ficha? (s/n): ').strip().lower()=='s': ficha=completar_ficha_con_preguntas(ficha)
    print(f'
Ficha guardada en: {guardar_ficha(ficha)}')
def _completar_ficha_existente():
    ficha_dict=_pedir_ficha_por_nombre()
    if not ficha_dict: return
    ficha=completar_ficha_con_preguntas(dict_a_ficha(ficha_dict)); print(f'
Ficha actualizada en: {guardar_ficha(ficha)}')
def _editar_ficha_inteligente():
    ficha=_pedir_ficha_por_nombre()
    if not ficha: return
    print('
Ficha seleccionada:'); print(f"{ficha.get('nombre')} | Código interno: {ficha.get('codigo')}")
    print('
Escribe el cambio en lenguaje natural. Ejemplos: La vida útil son 5 días / Añade Thermomix / Esta receta sale para 32 raciones')
    texto=input('
¿Qué quieres cambiar? ').strip(); campo,valor,descripcion=interpretar_cambio(texto); print(f'
Interpretación: {descripcion}')
    if campo=='desconocido': print('No aplico cambios porque no he entendido el campo.'); return
    if input('¿Aplicar cambio? (s/n): ').strip().lower()!='s': print('Cambio cancelado.'); return
    codigo=ficha.get('codigo'); campo_real=campo.replace('_add',''); anterior=copy.deepcopy(ficha.get(campo_real)); guardar_version(ficha,motivo='antes de edición inteligente')
    ficha=aplicar_cambio_a_dict(ficha,campo,valor); guardar_dict_ficha(ficha); registrar_cambio(codigo,campo,anterior,valor,'edición inteligente desde consola'); print('
Cambio guardado correctamente.')
def _duplicar_ficha():
    ficha=_pedir_ficha_por_nombre()
    if not ficha: return
    nuevo_nombre=input('
Nuevo nombre de la ficha duplicada: ').strip(); nuevo_codigo=input('Nuevo código interno: ').strip()
    if not nuevo_nombre or not nuevo_codigo: print('Nombre y código son obligatorios.'); return
    nueva=copy.deepcopy(ficha); nueva['nombre']=nuevo_nombre; nueva['codigo']=nuevo_codigo; nueva['estado']='borrador'; guardar_dict_ficha(nueva); registrar_cambio(nuevo_codigo,'duplicada_desde',ficha.get('codigo'),nuevo_codigo,'duplicar ficha'); print('
Ficha duplicada correctamente.')
def _validar_ficha():
    ficha=_pedir_ficha_por_nombre()
    if not ficha: return
    if ficha.get('preguntas_pendientes'):
        print('
La ficha todavía tiene campos pendientes:')
        for p in ficha.get('preguntas_pendientes',[]): print(f'- {p}')
        if input('
¿Validarla igualmente? (s/n): ').strip().lower()!='s': print('Validación cancelada.'); return
    anterior=ficha.get('estado'); guardar_version(ficha,motivo='antes de validar'); ficha['estado']='validada'; guardar_dict_ficha(ficha); registrar_cambio(ficha.get('codigo'),'estado',anterior,'validada','validación manual'); print('
Ficha validada.')
def _historial_ficha():
    ficha=_pedir_ficha_por_nombre()
    if not ficha: return
    historial=leer_historial(ficha.get('codigo'))
    if not historial: print('
No hay historial para esta ficha.'); return
    print('
HISTORIAL'); print('='*70)
    for h in historial:
        print(f"{h.get('fecha')} | {h.get('campo')}"); print(f"  Antes: {h.get('anterior')}"); print(f"  Nuevo: {h.get('nuevo')}")
        if h.get('motivo'): print(f"  Motivo: {h.get('motivo')}")
def _buscar_fichas():
    texto=input('
Buscar por nombre, código, ingrediente, maquinaria o familia: ').strip(); resultados=buscar_fichas_por_texto(texto); q=texto.lower()
    for f in listar_fichas():
        data=cargar_ficha(f.stem)
        if not data or data in resultados: continue
        campos=[data.get('familia',''),' '.join(data.get('maquinaria_imprescindible',[])),' '.join(data.get('alergenos',[])),' '.join(i.get('nombre','') for i in data.get('ingredientes',[]))]
        if q in ' '.join(campos).lower(): resultados.append(data)
    if not resultados: print('
No he encontrado fichas.'); return
    print('
RESULTADOS'); print('='*70)
    for r in resultados: print(f"- {r.get('nombre')} | Código interno: {r.get('codigo')} | Familia: {r.get('familia','')}")
def _explicar_ficha_host_ai(): print('
FICHA TÉCNICA HOST AI v1.0
'+'='*70+'
Sprint 5.9 añade edición inteligente, búsqueda por nombre, duplicado, validación e historial.')

def menu_fichas_tecnicas(restaurante_id:int=1)->None:
    while True:
        print('
'+'='*60); print('17. FICHAS TÉCNICAS HOST AI'); print('='*60)
        print('1. Crear ficha demo completa: Carrillera melosa'); print('2. Listar fichas guardadas'); print('3. Ver ficha como cocinero'); print('4. Crear borrador desde receta pegada y completar preguntas'); print('5. Explicar estructura Ficha Técnica Host AI v1.0'); print('6. Completar ficha existente'); print('7. Editar ficha inteligente'); print('8. Duplicar ficha'); print('9. Validar ficha'); print('10. Ver historial de cambios'); print('11. Buscar fichas'); print('0. Volver')
        opcion=input('
Elige una opción: ').strip()
        if opcion=='1': _crear_demo_carrillera(); _pausa()
        elif opcion=='2': _listar_fichas(); _pausa()
        elif opcion=='3': _ver_ficha(); _pausa()
        elif opcion=='4': _crear_borrador_desde_texto(); _pausa()
        elif opcion=='5': _explicar_ficha_host_ai(); _pausa()
        elif opcion=='6': _completar_ficha_existente(); _pausa()
        elif opcion=='7': _editar_ficha_inteligente(); _pausa()
        elif opcion=='8': _duplicar_ficha(); _pausa()
        elif opcion=='9': _validar_ficha(); _pausa()
        elif opcion=='10': _historial_ficha(); _pausa()
        elif opcion=='11': _buscar_fichas(); _pausa()
        elif opcion=='0': break
        else: print('Opción no válida.')
if __name__=='__main__': menu_fichas_tecnicas()
